package sessio2;

public class Game {
	
	private static char PLAYER1 = 'X';
	private static char PLAYER2 = 'O';
	
	//TODO: Add attributes as described in the document
	
	//TODO: Add methods
	
	
	
}
