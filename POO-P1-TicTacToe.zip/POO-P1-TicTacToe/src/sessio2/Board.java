package sessio2;

public class Board {
	
	private final static int SIZE=3; 

	//TODO: Add additional private attributes. 
	
	//TODO: Add methods as described in the document
	
	
}