package sessio1;

import java.awt.Toolkit;

import jconsole.JConsole;

public class TicTacToeGame {

	public static void main(String[] args) {
		
		//Two consoles, AVOID CHANGING
		JConsole gameConsole = new JConsole(30,10);
		JConsole userInput = new JConsole(60,15);
		
		char [][] board;
		boolean gameEnded;
		boolean exit;
		char player1 = 'X';
		char player2 = 'O';
		char currentPlayer = player1;
		
		//TODO: Declare more variables here if you need them.
		
		//Screen size, AVOID CHANGING
		int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		int halfWidthGame = (screenWidth)/4;
		int halfHeightPlayer = (screenHeight)/2;
		
		//Console positioning
		gameConsole.setLocation(halfWidthGame,10);
		userInput.setLocation(halfWidthGame,halfHeightPlayer);
		
		//We hide the cursor in the game console
		gameConsole.setCursorVisible(false);

		
		//TODO: Show main menu
		//TODO: We initialize the variables with some dummy values, feel free to change them if you need to
		exit = false;
		gameEnded = false;
		
		while(!exit) {
			//Game begins
			
			//TODO: Prepare board and show it
			
			while(!gameEnded) {
				//TODO: Interact with user and make move
				//Make sure that after a valid move current player changes
				
			}
			
			//TODO: Whatever needs to be done when a game has finished
			
			//TODO: Do not forget that the user should be able to play a new game when another game has ended
			
		}
		
		//We should only reach this point when the user has decided to exit the game. DO NOT MAKE ANY CHANGES HERE.
		userInput.setCursorPosition(0, userInput.getRows()-1);
		userInput.print("Press any key to exit...");
		userInput.readKey();
		System.exit(0);
		
	}
	
	//Private static procedures below. Some of them return dummy values, make sure to change them as appropriate.
	
	/**
	 * Shows main menu and returns option selected by user
	 * @param console
	 * @return
	 */
	private static int showMenuAndSelectOption(JConsole console) {
		/*TODO: Complete*/
		return -1;
	}


	/**
	 * Initializes board with empty spaces
	 * @param board
	 */
	private static void initializeBoard(char[][] board) {
		/*TODO: Complete*/
	}
	
	
	/**
	 * Shows board on console
	 * @param console
	 * @param board
	 */
	private static void showBoard(JConsole console, char[][] board) {
		/*TODO: Complete*/
	}
	
	
	/**
	 * Interacts with user to obtain some valid (within the given parameters) coordinates.
	 * @param console
	 * @param nRows
	 * @param nCols
	 * @return
	 */
	private static int[] getAndValidateCoordinates(JConsole console, int nRows, int nCols) {
		/*TODO: Complete*/
		return null;
	}
	
	
	/**
	 * Coordinates must be valid and player too. Returns true if move can be performed, false otherwise.
	 * @param board
	 * @param coord
	 * @param player
	 * @return
	 */
	private static boolean move(char[][] board, int[] coord, char player) {
		/*TODO: Complete*/
		return false;
	}
	
	/**
	 * Checks if the given board is full. Should return true if it's full, false otherwise 
	 * @param board
	 * @return
	 */
	private static boolean isBoardFull(char[][] board) {
		/*TODO: Complete*/
		return false;
	}
	
	/**
	 * Returns true if the player has won the game, false otherwise.
	 * @param board
	 * @param player
	 * @return
	 */
	private static boolean hasPlayerWon(char[][] board, char player) {
		/*TODO: Complete*/
		return false;
	}


}
